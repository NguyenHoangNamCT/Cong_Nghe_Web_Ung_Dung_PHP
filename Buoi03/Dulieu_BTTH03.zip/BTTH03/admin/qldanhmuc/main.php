<?php include("../view/top.php"); ?>

<h3>Quản lý danh mục</h3> 
<br>


<?php include("../view/bottom.php"); ?>
