<?php
header("location:qldanhmuc");
?>