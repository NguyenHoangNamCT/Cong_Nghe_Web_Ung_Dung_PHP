<?php
header("location:admin/qldanhmuc");
?>