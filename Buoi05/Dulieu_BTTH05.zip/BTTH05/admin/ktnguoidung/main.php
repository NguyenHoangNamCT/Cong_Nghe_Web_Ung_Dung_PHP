<?php include("../view/top.php"); ?>
<div>

<h3>Trang quản trị</h3>
<h4>Chào <?php echo $_SESSION["nguoidung"]["hoten"]; ?>! Chúc một ngày tốt lành!</h4>
<p>SV hãy bổ sung nội dung tùy thích...</p>

</div>
<?php include("../view/bottom.php"); ?>
