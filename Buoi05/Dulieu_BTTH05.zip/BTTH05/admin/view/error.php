<h3>Có sự cố xảy ra...</h3>
<p><?php echo $error_message; ?></p>
<h4>Vui lòng nhấn <a href="../index.php">vào đây</a> để quay về bảng điều khiển.</h4>