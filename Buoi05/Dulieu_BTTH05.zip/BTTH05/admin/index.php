<?php
session_start();
header("location:ktnguoidung");
?>